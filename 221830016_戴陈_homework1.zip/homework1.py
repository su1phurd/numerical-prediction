import xarray as xr#文件夹第三类简化
import numpy as np
import matplotlib.pyplot as plt
import os
import concurrent.futures
from functools import partial
from matplotlib.ticker import ScalarFormatter
from matplotlib.colors import Normalize

# 常量定义
R = 6371e3  # 地球半径，单位：米
g = 9.81    # 重力加速度
omega = 7.2921e-5  # 地球自转角速度
scale_factor = 1e4  # 单位转换系数

# 经度设置
LON_TICKS = [0, 60, 120, 180, 240, 300, 360]
LON_LABELS = ['0°', '60°E', '120°E', '180°', '120°W', '60°W', '0°']

# 数据文件配置
latitudes = ['75N', '45N', '15N', '0']
data_files = {
    '75N': 'NetCDF/hLat.198101-201012.clt.nc',
    '45N': 'NetCDF/mLat.198101-201012.clt.nc',
    '15N': 'NetCDF/lLat.198101-201012.clt.nc',
    '0': 'NetCDF/ELat.198101-201012.clt.nc'
}

# ==== 核心函数 ====
def extend_data(data):
    """扩展经度维度：添加360°点（值等于0°）"""
    return np.concatenate([data, data[..., [0]]], axis=3)

def extend_lon(lon_original):
    """扩展经度坐标到360°"""
    return np.append(lon_original, 360.0)

def validate_boundaries(data, var_name):
    """静默验证并修复边界（针对扩展后数据）"""
    data[..., -1] = data[..., 0]  # 强制360°=0°

def calculate_gradients(u, h, dx):
    """基于扩展数据的梯度计算"""
    validate_boundaries(u, 'U wind')
    validate_boundaries(h, 'Geopotential height')
    
    u_roll = np.roll(u, shift=-1, axis=3)
    dudx = (u_roll - np.roll(u, shift=1, axis=3)) / (2 * dx)
    
    h_roll = np.roll(h, shift=-1, axis=3)
    dhdx = (h_roll - np.roll(h, shift=1, axis=3)) / (2 * dx)
    
    return dudx, dhdx

# ==== 绘图函数 ====
def plot_first_type(year, term1, term2, term3, lon, levels, lat):
    """第一类图：年际平均经向分布"""
    output_dir = f'output/first_type/{year}/{lat}'
    os.makedirs(output_dir, exist_ok=True)
    
    avg_term1 = term1.mean(axis=0)  # (17,1,145)
    avg_term2 = term2.mean(axis=0)
    avg_term3 = term3.mean(axis=0)
    
    for lev_idx, lev in enumerate(levels):
        plt.figure(figsize=(15, 8))
        
        plt.plot(lon, avg_term1[lev_idx,0,:]*scale_factor, label='-u*du/dx')
        plt.plot(lon, avg_term2[lev_idx,0,:]*scale_factor, label='-fv')
        plt.plot(lon, avg_term3[lev_idx,0,:]*scale_factor, label='-g*dh/dx')
        
        plt.xticks(LON_TICKS, LON_LABELS)
        plt.xlim(0, 360)
        plt.title(f'{year} Annual Mean at {lev}hPa ({lat})')
        plt.xlabel('Longitude')
        plt.ylabel('Value (×10⁻⁴ m/s²)')
        plt.legend()
        plt.grid(True, linestyle='--', alpha=0.5)
        
        plt.savefig(f'{output_dir}/first_{lev}hPa_{year}.png', dpi=300, bbox_inches='tight')
        plt.close()

def plot_second_type_hovmoller(year, term, lon, levels, lat, term_name):
    """第二类图：年时间-经度Hovmöller图"""
    output_dir = f'output/second_type/{year}/{term_name}/{lat}'
    os.makedirs(output_dir, exist_ok=True)
    
    months = np.arange(1,13)
    
    for lev_idx, lev in enumerate(levels):
        plt.figure(figsize=(18, 6))
        data = term[:, lev_idx, 0, :] * scale_factor  # (12,145)
        
        X, Y = np.meshgrid(lon, months)
        plt.pcolormesh(X, Y, data, cmap='RdBu_r', shading='gouraud', norm=Normalize(-5,5))
        
        plt.xticks(LON_TICKS, LON_LABELS)
        plt.xlim(0, 360)
        plt.title(f'{year} {term_name} at {lev}hPa ({lat})')
        plt.xlabel('Longitude')
        plt.ylabel('Month')
        plt.yticks(months, [f'{m:02d}' for m in months])
        plt.colorbar(label=f'{term_name} (×10⁻⁴ m/s²)')
        
        plt.savefig(f'{output_dir}/second_{lev}hPa_{year}.png', dpi=300, bbox_inches='tight')
        plt.close()

def plot_third_type_hovmoller(year, term, lon, levels, lat, term_name):
    """第三类图：垂直剖面Hovmöller图"""
    for month in range(12):
        output_dir = f'output/third_type/{year}/month{month+1:02d}/{lat}'
        os.makedirs(output_dir, exist_ok=True)
        
        plt.figure(figsize=(20, 10))
        data = term[month, :, 0, :] * scale_factor  # (17,145)
        
        X, Y = np.meshgrid(lon, levels)
        plt.pcolormesh(X, Y, data, cmap='RdBu_r', shading='gouraud', norm=Normalize(-10,10))
        
        plt.yscale('log')
        plt.gca().yaxis.set_major_formatter(ScalarFormatter())
        plt.gca().invert_yaxis()
        plt.yticks([1000,500,200,100,50,10], [1000,500,200,100,50,10])
        plt.xticks(LON_TICKS, LON_LABELS, rotation=45)
        plt.xlim(0, 360)
        
        plt.title(f'{year} {term_name} Vertical Profile ({lat}) Month {month+1}')
        plt.xlabel('Longitude')
        plt.ylabel('Pressure Level (hPa)')
        plt.colorbar(label=f'{term_name} (×10⁻⁴ m/s²)')
        
        plt.savefig(f'{output_dir}/third_{term_name}_month{month+1:02d}.png', dpi=300, bbox_inches='tight')
        plt.close()

# ==== 主处理流程 ====
def process_year(year, lat_str):
    """处理单个年份和纬度的组合"""
    print(f"Processing {year} {lat_str}...")
    
    # 读取并扩展数据
    ds = xr.open_dataset(data_files[lat_str])
    u = extend_data(ds['uwnd'].values)  # (12,17,1,145)
    v = extend_data(ds['vwnd'].values)
    h = extend_data(ds['hgt'].values)
    lon = extend_lon(ds['lon'].values)
    levels = ds['lev'].values
    
    # 计算参数
    lat_deg = float(lat_str[:-1]) if lat_str != '0' else 0.0
    dx = R * np.cos(np.deg2rad(lat_deg)) * np.deg2rad(2.5)
    f = 2 * omega * np.sin(np.deg2rad(lat_deg))
    
    # 计算梯度项
    dudx, dhdx = calculate_gradients(u, h, dx)
    term1 = -u * dudx
    term2 = -f * v
    term3 = -g * dhdx
    
    # 绘图
    plot_first_type(year, term1, term2, term3, lon, levels, lat_str)
    plot_second_type_hovmoller(year, term1, lon, levels, lat_str, '-u_du_dx')
    plot_second_type_hovmoller(year, term2, lon, levels, lat_str, '-fv')
    plot_second_type_hovmoller(year, term3, lon, levels, lat_str, '-g_dhdx')
    plot_third_type_hovmoller(year, term1, lon, levels, lat_str, '-u_du_dx')
    plot_third_type_hovmoller(year, term2, lon, levels, lat_str, '-fv')
    plot_third_type_hovmoller(year, term3, lon, levels, lat_str, '-g_dhdx')

# ==== 主程序 ====
if __name__ == '__main__':
    # 预创建所有目录
    years = range(1981, 2010)
    for year in years:
        for lat in latitudes:
            os.makedirs(f'output/first_type/{year}/{lat}', exist_ok=True)
            for term in ['-u_du_dx', '-fv', '-g_dhdx']:
                os.makedirs(f'output/second_type/{year}/{term}/{lat}', exist_ok=True)

    # 并行处理
    with concurrent.futures.ProcessPoolExecutor(max_workers=os.cpu_count()//2) as executor:
        futures = [executor.submit(partial(process_year, year=y, lat_str=lat))
                  for y in years
                  for lat in latitudes]
        
        # 进度监控
        for i, future in enumerate(concurrent.futures.as_completed(futures)):
            print(f'Progress: {i+1}/{len(futures)}')
    
    print("处理完成！结果保存在output目录")